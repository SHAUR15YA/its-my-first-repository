#include<stdio.h>
int main()
{
    int marks[3] = 55,56,57
    printf("enter hindi : ");
    scanf("%d", &marks[0])

printf("enter english : ");
    scanf("%d", &marks[1])

    printf("enter math : ");
    scanf("%d", &marks[2])

    printf("hindi = %d, english = %d, math = %d", marks[0], marks[1], marks[2]);

    return 0;
} 